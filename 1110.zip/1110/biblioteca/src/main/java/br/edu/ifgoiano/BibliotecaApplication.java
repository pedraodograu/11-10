package br.edu.ifgoiano;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.edu.ifgoiano.entidade.Livro;
import br.edu.ifgoiano.repository.LivroRepository;

@SpringBootApplication
public class BibliotecaApplication implements CommandLineRunner {

	@Autowired
	private LivroRepository livroRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(BibliotecaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//Criar registros de Livros
		Livro livro1 = new Livro();
		livro1.setNome("7 Passos para felicidade");
		livro1.setIsbn("2323325");
		livro1.setAutor("Isaac Jef");
		
		Livro livro2 = new Livro();
		livro2.setAutor("Acsa SV");
		livro2.setIsbn("3212154142");
		livro2.setNome("Felicidade constante");
		
		Livro livro3 = new Livro();
		livro3.setAutor("Naboa Kev");
		livro3.setIsbn("3212154142");
		livro3.setNome("Vida feliz, sentimento triste");
		
		livroRepository.save(livro1);
		livroRepository.save(livro2);
		livroRepository.save(livro3);
	}
}